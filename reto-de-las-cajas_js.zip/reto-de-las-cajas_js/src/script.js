// Inicio de script para el reto de las cajas, DOM JS//

//1.Cuando hjaga click en el btn-cajas-itulose cambie el titulo de las cajas//

document.getElementById("btn-cajas-titulo").addEventListener("click",()=>
    {
  
  const titulocajas = 
        document.getElementById("titulo-cajas");
  titulocajas.textContent = "Ian Castillo";
});

//2. Cambiar el color de la caja//

document.getElementById("btn-color-cajas").addEventListener("click",()=>
{
 const cajas =
  document.getElementByClassName("caja");
  for (let i = 0; i < cajas.lenght; i++)
    {
      cajas[i].style.backgroundColor = "red";
    }
 
});

//3. Cambiar el color de la primera caja//

document.getElementById("btn-primera-caja").addEventListener("click",()=>
 {
  const primeracaja =
        document.querySelector(".caja");
  primeracaja.style.backgroundColor = " #27F5EB";
});

//Cambiar el color al borde de las cajas//

document.getElementById("btn-borde").addEventListener("click",()=>       {
  const bordecaja =
        
        document.querySelectorAll(".caja");
  bordecaja.forEach(caja =>
                   {
    caja.style.border = "10px solid purple";
  });
  
});