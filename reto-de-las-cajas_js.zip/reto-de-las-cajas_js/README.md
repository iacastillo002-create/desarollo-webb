# Reto de las cajas_JS

A Pen created on CodePen.

Original URL: [https://codepen.io/IAN-ALEJANDRO-CASTILLOCORREA/pen/PwZOJvj](https://codepen.io/IAN-ALEJANDRO-CASTILLOCORREA/pen/PwZOJvj).

